# FROM KAKLAMANOS SCRIPT STYLE

periods.bi <- function(positive = FALSE){

  # Return list of periods excluding PGA and PGV
  if(positive){
    T <- c(0.02, 0.04, 0.07, 0.10, 0.15, 0.20, 0.26, 0.30, 0.36, 0.40,
           0.46, 0.50, 0.6, 0.7, 0.8, 0.9, 1.0, 1.3, 1.5, 1.8, 2.0, 2.6, 
           3.0, 4.0)

  # Return list of periods including PGA and PGV
  }else{
    T <- c(0.02, 0.04, 0.07, 0.10, 0.15, 0.20, 0.26, 0.30, 0.36, 0.40,
           0.46, 0.50, 0.6, 0.7, 0.8, 0.9, 1.0, 1.3, 1.5, 1.8, 2.0, 2.6, 
           3.0, 4.0 ,0,-1)
  }
return(T)
}

# 1b. Period-independent coefficients
coefs.bi <- function(){

  c("Vref = 800", "Mh = 6.75","Mref = 5.5", "Rref = 1.0")
}

# Site amplification coefficients
blin.bi <- function(T) {
  Period.list <- periods.ba()
  blin.list <- c( -0.294021,-0.241765,-0.207629,-0.173237,-0.202492,-0.291228,
  -0.354425,-0.39306,-0.453905,-0.492063,-0.564463,-0.596196,-0.667824,
  -0.73839,-0.794076,-0.821699,-0.826584,-0.845047,-0.8232,-0.778657,
  -0.769243,-0.769609,-0.732072,-0.699959,-0.301899,-0.529443)

  blin.list[match(T, Period.list)]
}
# Off-set
e1.bi <- function(T) {
  Period.list <- periods.ba()
  e1.list <- c(3.37053,3.43922,3.59651,3.68638,3.68632,3.68262,3.64314,3.63985,
  3.5748,3.53006,3.43387,3.40554,3.30442,3.23882,3.1537,3.13481,3.12474,2.89841,
  2.84727,2.68016,2.60171,2.39067,2.25399,2.00957,3.32819,2.26481)
  e1.list[match(T, Period.list)]
}
#geo-spread
c1.bi <- function(T) {
  Period.list <- periods.ba()
  c1.list <- c(-1.26358,-1.31025,-1.29051,-1.28178,-1.17697,-1.10301,-1.08527,
  -1.10591,-1.09955,-1.09538,-1.06586,-1.05767,-1.05014,-1.05021,-1.04654,-1.04612,
  -1.0527,-0.973828,-0.983388,-0.983082,-0.979215,-0.977532,-0.940373,-0.864016,
  -1.2398,-1.22408)
  c1.list[match(T, Period.list)]
}
#geo-spread-mag
c2.bi <- function(T) {
  Period.list <- periods.ba()
  c2.list <- c(0.220527,0.244676,0.231878,0.219406,0.182662,0.133154,0.115603,
  0.108276,0.103083,0.101111,0.109066,0.112197,0.121734,0.114674,0.129522,0.114536,
  0.103471,0.104898,0.109072,0.164027,0.163344,0.211831,0.227241,0.232116,
  0.21732,0.202085)
  c2.list[match(T, Period.list)]
}

#h
h.bi <- function(T) {
  Period.list <- periods.ba()
  h.list <- c(5.20082,4.91669,5.35922,6.12146,5.74154,5.31998,5.13455,5.12846,
  4.90557,4.95386,4.6599,4.43205,4.21657,4.17127,4.20016,4.48003,4.41613,4.25821,
  4.56697,4.68008,4.58186,5.39517,5.74173,5.80092,5.26486,5.06124)
  h.list[match(T, Period.list)]
}

#c3
c3.bi <- function(T) {
  Period.list <- periods.ba()
  c3.list <- c(0.00111816,0.00109183,0.00182094,0.00211443,0.00254027,0.00242089,
  0.00196437,0.00149922,0.00104905,0.000851474,0.000868165,0.000788528,0.000487285,
  0.000159408,0,0,0,0,0,0,0,0,0,0.0008387,0.00118624,0)
  c3.list[match(T, Period.list)]
}

#b1
b1.bi <- function(T) {
  Period.list <- periods.ba()
  b1.list <- c(-0.0890554,-0.116919,-0.0850124,-0.11355,-0.0928726,0.0100857,
  0.0299397,0.0391904,0.052103,0.0458464,0.0600838,0.0883189,0.120182,0.166933,
  0.193817,0.247547,0.306569,0.349119,0.384546,0.343663,0.331747,0.357514,
  0.385526,0.526662,-0.0855045,0.162802)
  b1.list[match(T, Period.list)]
}

#b2
b2.bi <- function(T) {
  Period.list <- periods.ba()
  b2.list <- c(-0.0916152,-0.0783789,-0.0569968,-0.0753325,-0.102433,-0.105184,
  -0.127173,-0.138578,-0.151385,-0.16209,-0.165897,-0.164108,-0.163325,-0.161112,
  -0.156553,-0.153819,-0.147558,-0.149483,-0.139867,-0.135933,-0.148282,-0.122539,
  -0.111445,-0.0664914,-0.0925639,-0.0926324)
  b2.list[match(T, Period.list)]
}

#b3
b3.bi <- function(T) {
  Period.list <- periods.ba()
  b3.list <- c(0,0,0,0,0.0739042,0.150461,0.178899,0.189682,0.216011,0.224827,
  0.197716,0.15475,0.117576,0.112005,0.0517285,0.0815754,0.0928373,0.108209,
  0.0987372,0,0,0,0,0,0,0.0440301)
  b3.list[match(T, Period.list)]
}

#SOF N
sofN.bi <- function(T) {
  Period.list <- periods.ba()
  sofN.list <- c(-0.039236,-0.0377204,-0.0459437,-0.0380528,-0.0267293,-0.0326537,
  -0.0338438,-0.0372453,-0.0279067,-0.0256309,-0.0186635,-0.0174194,-0.000486417,
  0.0112033,0.0165258,0.0164493,0.0263071,0.0252339,0.0186738,0.0113713,
  0.00553545,0.0087346,0.0229893,0.0609869,-0.0397695,-0.00947675)
  sofN.list[match(T, Period.list)]
}

#SOF R
sofR.bi <- function(T) {
  Period.list <- periods.ba()
  sofR.list <- c(0.0810516,0.0797783,0.0874968,0.0847103,0.0678441,0.0759769,
  0.074982,0.0767011,0.0697898,0.0725668,0.0645993,0.0602826,0.0449209,0.0281506,
  0.0203522,0.0212422,0.0186043,0.0223621,0.0230894,0.0166882,0.0198566,0.0233142,
  -0.020662,-0.0528117,0.0775253,0.0400574)
  sofR.list[match(T, Period.list)]
}

#SOF S
sofS.bi <- function(T) {
  Period.list <- periods.ba()
  sofS.list <- c(-0.0418156,-0.0420579,-0.041553,-0.0466585,-0.0411147,-0.0433232,
  -0.0411381,-0.0394559,-0.0418832,-0.046936,-0.0459358,-0.0428632,-0.0444345,
  -0.0393539,-0.0368783,-0.0376913,-0.0449111,-0.0475957,-0.041763,-0.0280594,
  -0.025392,-0.0320486,-0.00232715,-0.00817519,-0.0377558,-0.0305805)
  sofS.list[match(T, Period.list)]
}

#SIGMS
sig.bi <- function(T) {
  Period.list <- periods.ba()
  sig.list <- c(0.323885,0.329654,0.33886,0.346379,0.3419,0.335532,0.338114,
  0.336741,0.337694,0.336278,0.33929,0.341717,0.344388,0.345788,0.3452,0.350517,
  0.356067,0.356504,0.362835,0.36502,0.368857,0.363037,0.360373,0.30698,0.319753,0.31856)
  sig.list[match(T, Period.list)]
}

########################################################################################
# 2a. Distance Function
Fd.bi <- function(M, Rjb, T)
  {
    # Load period-independent coefficients
    coefs.list <- coefs.bi()
    for(i in 1:length(coefs.list))
      eval(parse(text = coefs.list[i]))

    # Calculate R (Eqn 3)
    R <- sqrt(Rjb^2 + (h.bi(T))^2)

    # Return Fd (Eqn 4)
    return((c1.bi(T) + c2.bi(T)*(M - Mref))*log10(R / Rref) - c3.bi(T)*(R - Rref))
  }

# 2b. Magnitude Function
Fm.bi <- function(M, SS, NS, RS, T)
  {
# Load period-independent coefficients
    coefs.list <- coefs.bi()
    for(i in 1:length(coefs.list))
      eval(parse(text = coefs.list[i]))

    if(M <= Mh)  # Eqn 3
      {
        return(e1.bi(T)+sofS.bi(T)*SS + sofN.bi(T)*NS + sofR.bi(T)*RS + 
        b1.bi(T)*(M - Mh) + b2.bi(T)*(M - Mh)^2)
      } else
    if(M > Mh)  # Eqn 3
      {
        return(e1.bi(T)+sofS.bi(T)*SS + sofN.bi(T)*NS + sofR.bi(T)*RS + 
               b3.bi(T)*(M - Mh))
      }
  }

# 2c. Site Amplification Function
Fs.bi <- function(Vs30,T)
  {
# Load period-independent coefficients
    coefs.list <- coefs.ba()
    for(i in 1:length(coefs.list))
    eval(parse(text = coefs.list[i]))

    Flin <- blin.ba(T)*log10(Vs30 / Vref)
    return(Flin)
  }


#########################################################################

# 3. MEDIAN GROUND MOTION CALCULATION of Sa, PGA, and PGV
SaMedian.bi <- function(M, Rjb, Vs30, SS, NS, RS, T) {

  #  Bindi_et_al_14 calculation
  SaMedian <- 10^(Fm.bi(M, SS, NS, RS, T) + Fd.bi(M, Rjb, T) +
                  Fs.bi(Vs30, T))

  return(SaMedian)
}

#########################################################################

# 4. FINAL FUNCTION FOR BA08 GROUND MOTION CALCULATIONS
Sa.bi <- function(M, Rjb, Vs30, epsilon, T, SS = NA, NS = NA, RS = NA){

  # If T is a vector, perform calculation for each of the elements
  if(length(T) > 1) {
    return(sapply(T, Sa.bi, M = M, Rjb = Rjb, Vs30 = Vs30, epsilon = epsilon,
                  SS = SS, NS = NS, RS = RS))

  # Perform calculation for single value of T:
  } else {
    # 4A. CHECK INPUT PARAMETERS
    # Check mandatory input parameters
    if(is.na(M) == TRUE | M < 0)
      stop("M must be a positive number")
    if(is.na(Rjb) == TRUE | Rjb < 0)
      stop("Rjb must be a non-negative number")
    if(is.na(Vs30) == TRUE | Vs30 < 0)
      stop("Vs30 must be a positive number")
    if(is.na(epsilon) == TRUE)
      stop("epsilon must be numeric")

      # Compute median
      LnSaMedian <- log10(SaMedian.bi(M, Rjb, Vs30, SS, NS, RS, T))
      epsilon.sigmaTot <- epsilon * sig.bi(T)   
      LnSa <- LnSaMedian + epsilon.sigmaTot
      return(10^(LnSa)/981)   # [g]
  }
}














