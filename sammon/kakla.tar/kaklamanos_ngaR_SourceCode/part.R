
# 4. FINAL FUNCTION FOR BA08 GROUND MOTION CALCULATIONS
Sa.ba <- function(M, Rjb, Vs30, epsilon, T, rake = NA, U = NA, SS = NA, NS = NA, RS = NA, AB11 = 0){

  # If T is a vector, perform calculation for each of the elements
  if(length(T) > 1) {
    return(sapply(T, Sa.ba, M = M, Rjb = Rjb, Vs30 = Vs30, epsilon = epsilon,
                  rake = rake, U = U, SS = SS, NS = NS, RS = RS, AB11 = AB11))

  # Perform calculation for single value of T:
  } else {

    
    # 4A. CHECK INPUT PARAMETERS

    # Check mandatory input parameters
    if(is.na(M) == TRUE | M < 0)
      stop("M must be a positive number")
    if(is.na(Rjb) == TRUE | Rjb < 0)
      stop("Rjb must be a non-negative number")
    if(is.na(Vs30) == TRUE | Vs30 < 0)
      stop("Vs30 must be a positive number")
    if(is.na(epsilon) == TRUE)
      stop("epsilon must be numeric")

    # Check style-of-faulting parameters
    if(is.na(rake) == TRUE & (is.na(U) == TRUE | is.na(SS) == TRUE |
                   is.na(NS) == TRUE | is.na(RS) == TRUE))
      stop("either (1) the rake angle, or (2) all the style-of-faulting flag variables", "\n",
           "(U, SS, NS, and RS) must be specified")
    if(is.na(rake) == FALSE & (is.na(U) == FALSE | is.na(SS) == FALSE |
                   is.na(NS) == FALSE | is.na(RS) == FALSE) &
       (is.na(U) == TRUE | is.na(SS) == TRUE | is.na(NS) == TRUE |
        is.na(RS) == TRUE))
      stop("either (1) the rake angle, or (2) all the style-of-faulting flag variables", "\n",
           "(U, SS, NS, and RS) must be specified")
    if(is.na(rake) == TRUE & U + SS + NS + RS != 1)
      stop("exactly one style-of-faulting flag variable (U, SS, NS, or RS) must be equal to 1")
  
    # Check for consistency, if both rake and style-of-faulting parameters are supplied
    if(is.na(rake) == FALSE & (is.na(U) == FALSE | is.na(SS) == FALSE |
                   is.na(NS) == FALSE | is.na(RS) == FALSE)){
      if(U + SS + NS + RS != 1)
        stop("exactly one style-of-faulting flag variable (U, SS, NS, or RS) must be equal to 1")
      if(U == 1)
        stop("for unspecified faulting (U = 1), the rake should not be passed as an argument")
      else{
        if(NS == 1 & !(rake >= -150 & rake <= -30))
          stop("inconsistency between rake and NS:  for NS = 1, the rake must be between -150 and -30, inclusive")
        if(RS == 1 & !(rake >=30 & rake <= 150))
          stop("inconsistency between rake and RS:  for RS = 1, the rake must be between 30 and 150, inclusive")
        if(SS == 1 & !(abs(rake) < 30 | abs(rake) > 150))
          stop("inconsistency between rake and SS:  for SS = 1, the rake cannot be in the ranges for normal or reverse faulting")
      }
    }


    # 4B. OBTAIN ESTIMATES OF UNSPECIFIED INPUT PARAMETERS
    
    # Convert rake to fault type, if fault type not provided
    if(is.na(U) == TRUE){
      # Normal faulting
      if(rake >= -150 & rake <= -30){
        U <- 0
        NS <- 1
        RS <- 0
        SS <- 0
        # Reverse faulting   
      } else{
        if(rake >= 30 & rake <= 150){
          U <- 0
          NS <- 0
          RS <- 1
          SS <- 0
          # Strike-slip faulting
        } else{
          U <- 0
          NS <- 0
          RS <- 0
          SS <- 1
        }
      }
    }


    # 4C. CALCULATE GROUND MOTION PARAMETER
    
    # Is interpolation necessary?
    interp <- getPeriod(T, "BA08")$interp

    # If interpolation is not necessary, compute Sa
    if(interp == FALSE){
      # Compute median
      LnSaMedian <- log(SaMedian.ba(M, Rjb, Vs30, U, SS, NS, RS, AB11, T))
      # Compute SD, depending on whether or not the fault mechanism is specified
      if(U == 0)
        epsilon.sigmaTot <- epsilon * SigmaTotM.ba(T)   # Specified fault mechanism
      else
        epsilon.sigmaTot <- epsilon * SigmaTotU.ba(T)   # Unspecified fault mechanism
      LnSa <- LnSaMedian + epsilon.sigmaTot
      return(exp(LnSa))
    } else{


    # If interpolation is necessary, compute Sa
      if(interp == TRUE){
        T1 <- getPeriod(T, "BA08")$lower
        T2 <- getPeriod(T, "BA08")$upper    
      
        # Calculation for T1
        LnSaMedian.T1 <- log(SaMedian.ba(M, Rjb, Vs30, U, SS, NS, RS, AB11, T1))
        if(U == 0)
          epsilon.sigmaTot.T1 <- epsilon * SigmaTotM.ba(T1)   # Specified fault mechanism
        else
          epsilon.sigmaTot.T1 <- epsilon * SigmaTotU.ba(T1)   # Unspecified fault mechanism
        LnSaT1 <- LnSaMedian.T1 + epsilon.sigmaTot.T1
      
        # Calculation for T2
        LnSaMedian.T2 <- log(SaMedian.ba(M, Rjb, Vs30, U, SS, NS, RS, AB11, T2))
        if(U == 0)
          epsilon.sigmaTot.T2 <- epsilon * SigmaTotM.ba(T2)   # Specified fault mechanism
        else
          epsilon.sigmaTot.T2 <- epsilon * SigmaTotU.ba(T2)   # Unspecified fault mechanism
        LnSaT2 <- LnSaMedian.T2 + epsilon.sigmaTot.T2
      
        # Interpolated value
        LnSa <- interpolate(log(T), log(T1), log(T2), LnSaT1, LnSaT2)
        return(exp(LnSa))
      }
    }
  }
}

