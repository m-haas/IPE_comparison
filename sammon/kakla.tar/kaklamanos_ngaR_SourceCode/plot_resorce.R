source("kaklamanos_ngaR_SourceCode/resorce.R")

M <- 5
Rjb <- 20
vs30 <- 800
epsilon <- 0
T <- 0.1
SS <- 0
NS <- 1
RS <- 0
rr<- c(0.1,1,2,4,6,8,10,12,15,20,30,40,50,60,70,80,90,100,120,140,160,180,200)
nmetri<-length(rr)
ncl<- nmetri
#valo <- Sa.bi(M, Rjb, Vs30, epsilon,T, SS,NS,RS)

plotReso <- array(0, c(1,ncl), list(NULL,c(1:ncl)))
plotReso <- list()

ii<-0
for (ik in 1:nmetri)
{
  ii<-ii+1
  plotReso[[ii]] <- Sa.bi(M = 6.5, Rjb = rr[ik], Vs30=Vs30, epsilon = 0, T = c(1,0.1,0.02,2),SS,NS,RS)
  
}

modelsR <- array(NA, c(nmetri, 1), list(NULL, c("BI")))
kk<-1
for (ij in 1:nmetri)
{
  modelsR[ij,1] <- (plotReso[[ij]][kk])
  }
df1r<-data.frame(modelsR)
df1r$r<-rr
ggplot()+
  geom_line(data=df1r,aes(r,BI),col="red")+
    scale_x_continuous(trans = "log10")+
  scale_y_continuous(trans = "log10")







